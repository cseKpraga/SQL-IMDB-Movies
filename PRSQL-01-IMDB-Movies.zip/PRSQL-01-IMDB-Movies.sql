USE project_movie_database;

SELECT 'a) All data about movies' AS task, movies.* FROM movies;

SELECT 'b) All data about directors' AS task, directors.* FROM directors;

SELECT 'c) Total movies' AS task, COUNT(*) AS total_movies FROM movies;

SELECT 'd) Three directors' AS task, directors.* FROM directors WHERE name IN ('James Cameron', 'Luc Besson', 'John Woo');

SELECT 'e) Directors starting with S' AS task, directors.* FROM directors WHERE name LIKE 'S%';

SELECT 'f) Female directors' AS task, COUNT(*) AS female_directors FROM directors WHERE gender = 1;

SELECT 'g) First 10 women directors' AS task, name FROM directors WHERE gender = 1 ORDER BY id LIMIT 10;

SELECT 'g) 10th woman director' AS task, name FROM directors WHERE gender = 1 ORDER BY id LIMIT 1 OFFSET 9;

SELECT 'h) 3 most popular movies' AS task, original_title, popularity FROM movies ORDER BY popularity DESC LIMIT 3;

SELECT 'i) 3 most bankable movies' AS task, original_title, budget, revenue, (revenue - budget) AS profit FROM movies ORDER BY profit DESC LIMIT 3;

SELECT 'j) Highest vote average since 2000' AS task, original_title, vote_average, release_date FROM movies WHERE release_date >= '2000-01-01' ORDER BY vote_average DESC LIMIT 1;

SELECT 'k) Brenda Chapman movies' AS task, m.original_title, d.name FROM movies m JOIN directors d ON m.director_id = d.id WHERE d.name = 'Brenda Chapman';

SELECT 'l) Director with most movies' AS task, d.name, COUNT(*) AS movie_count FROM movies m JOIN directors d ON m.director_id = d.id GROUP BY d.id, d.name ORDER BY movie_count DESC LIMIT 1;

SELECT 'm) Most bankable director' AS task, d.name, SUM(m.revenue - m.budget) AS total_profit FROM movies m JOIN directors d ON m.director_id = d.id GROUP BY d.id, d.name ORDER BY total_profit DESC LIMIT 1;
